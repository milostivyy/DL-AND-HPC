#include <iostream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <chrono>
using namespace std;
using namespace std::chrono;

const double LEARNING_RATE = 0.1;
const int MAX_EPOCHS = 1000;
auto start = high_resolution_clock::now();

#pragma omp parallel for reduction(+: result)
double dot_product(const vector<double>& v1, const vector<double>& v2) {
    double result = 0.0;
    for (int i = 0; i < v1.size(); i++) {
        result += v1[i] * v2[i];
    }
	return result;


	
}
auto stop = high_resolution_clock::now();


int classify(const vector<double>& features, const vector<double>& weights) {
    double dot = dot_product(features, weights);
    return (dot >= 0) ? 1 : -1;
}

void train_svm(const vector<vector<double>>& features, const vector<int>& labels, vector<double>& weights) {
    int num_features = features[0].size();
    int num_examples = features.size();
    weights.resize(num_features);

    for (int epoch = 0; epoch < MAX_EPOCHS; epoch++) {
       #pragma omp parallel for
        for (int i = 0; i < num_examples; i++) {
            int label = labels[i];
            vector<double> x = features[i];
            double y = label * dot_product(weights, x);
	    #pragma omp critical
            if (y < 1) {
                for (int j = 0; j < num_features; j++) {
                    weights[j] += LEARNING_RATE * (label * x[j] - 2 * weights[j] / num_examples);
                }
            }
        }
    }
}

int main() {
    srand(time(nullptr));

    // Generate random training data
    const int NUM_EXAMPLES = 1000;
    const int NUM_FEATURES = 10;
    vector<vector<double>> features(NUM_EXAMPLES, vector<double>(NUM_FEATURES));
    vector<int> labels(NUM_EXAMPLES);
    for (int i = 0; i < NUM_EXAMPLES; i++) {
        for (int j = 0; j < NUM_FEATURES; j++) {
            features[i][j] = rand() % 100 / 100.0;
        }
        labels[i] = (dot_product(features[i], features[i]) >= 0.5) ? 1 : -1;
    }

    // Train SVM
    vector<double> weights;
    train_svm(features, labels, weights);

    // Test SVM
    const int NUM_TEST_EXAMPLES = 10;
    vector<vector<double>> test_features(NUM_TEST_EXAMPLES, vector<double>(NUM_FEATURES));
    for (int i = 0; i < NUM_TEST_EXAMPLES; i++) {
        for (int j = 0; j < NUM_FEATURES; j++) {
            test_features[i][j] = rand() % 100 / 100.0;
        }
        int prediction = classify(test_features[i], weights);
        cout << "Test Example " << i+1 << ": ";
        for (int j = 0; j < NUM_FEATURES; j++) {
            cout << test_features[i][j] << " ";
        }
        cout << "Prediction: " << prediction << endl;
    }
auto duration = duration_cast<nanoseconds>(stop - start);
cout<<" time taken for dot product parallel reduction use: "<<duration.count()<<"in nanoseconds"<<endl;


    return 0;
}
