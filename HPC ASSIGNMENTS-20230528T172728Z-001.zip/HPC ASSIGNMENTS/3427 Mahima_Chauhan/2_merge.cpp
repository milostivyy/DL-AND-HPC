#include <iostream>  // standard input/output stream library
#include <vector>    // container for dynamic arrays
#include <omp.h>     // OpenMP library for parallelism
#include <random>    // random number generation library
#include <chrono>    // library for measuring time

using namespace std;
using namespace std::chrono;  // namespace for time measurement

// function to merge two sorted sub-arrays of a vector
void merge(vector<int>& arr, int l, int m, int r) {
    int i, j, k;
    int n1 = m - l + 1;      // size of left sub-array
    int n2 = r - m;          // size of right sub-array
    vector<int> L(n1), R(n2); // temporary arrays for merging

    // copy data to temporary arrays
    for (i = 0; i < n1; i++)
        L[i] = arr[l + i];
    for (j = 0; j < n2; j++)
        R[j] = arr[m + 1 + j];

    i = j = 0;   // initial indices for left and right sub-arrays
    k = l;       // initial index for merged sub-array

    // merge temporary arrays back into original vector
    while (i < n1 && j < n2) {
        if (L[i] <= R[j])
            arr[k++] = L[i++];
        else
            arr[k++] = R[j++];
    }

    // copy remaining elements of left sub-array (if any)
    while (i < n1)
        arr[k++] = L[i++];

    // copy remaining elements of right sub-array (if any)
    while (j < n2)
        arr[k++] = R[j++];
}

// recursive function to sort a vector using merge sort algorithm
void merge_sort(vector<int>& arr, int l, int r) {
    if (l < r) {  // if there is more than one element in sub-vector
        int m = l + (r - l) / 2;   // calculate midpoint
        merge_sort(arr, l, m);     // sort left sub-vector
        merge_sort(arr, m + 1, r); // sort right sub-vector
        merge(arr, l, m, r);       // merge sorted sub-vectors
    }
}

// function to perform parallel merge sort using OpenMP
void parallel_merge_sort(vector<int>& arr) {
#pragma omp parallel  // start parallel region
    {
#pragma omp single  // ensure only one thread starts sorting
        merge_sort(arr, 0, arr.size() - 1);  // perform merge sort on entire vector
    }
}

int main() {
    const int SIZE = 100;
    vector<int> arr(SIZE);   // vector of 100 integers
    unsigned seed = chrono::system_clock::now().time_since_epoch().count();  // seed for random number generation
    default_random_engine generator(seed);  // create random number generator
    uniform_int_distribution<int> distribution(1, 1000);  // range for random numbers
    for (int i = 0; i < SIZE; i++) {
        arr[i] = distribution(generator);  // assign random number to element of vector
    }
    vector<int>store=arr;  // make a copy of the vector for sequential sorting

    auto start = high_resolution_clock::now();  // get start time
    parallel_merge_sort(arr);  // perform parallel merge sort
    auto stop = high_resolution_clock::now();
   	auto duration = duration_cast<nanoseconds>(stop - start);
	cout<<" time taken by sequential merge sorting: "<<duration.count()<<endl;
for(int i=0;i<100;i++){
cout<<arr[i]<<" ";
}
cout<<endl;

	start = high_resolution_clock::now();
	merge_sort(store,0,99);
	stop = high_resolution_clock::now();
   	duration = duration_cast<nanoseconds>(stop - start);
	cout<<" time taken by parallel merge sorting: "<<duration.count()<<endl;
return 0;
}
