#include<bits/stdc++.h>
#include<omp.h>
#include<chrono>
using namespace std;
using namespace std::chrono;

void bubble_sort(int arr[],int n){

	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			if(arr[j]>arr[i]){
				swap(arr[j],arr[i]);
			}
		}	
	}
}

void Parallel_bubble_sort(int arr[],int n){
	
	bool swapped;	

	#pragma omp parallel default(none) shared(arr,n,swapped)
	{
		do{
			swapped = false;
			#pragma omp for
			for(int i=0;i<n-1;++i){
				if(arr[i] > arr[i+1]){
					swap(arr[i],arr[i+1]);
					swapped = true;
				}
			}	
		}while(swapped);
	}
}

void merge(int a[],int l, int md, int r){
	vector<int> temp(r-l+1);
	int i = l,j=md+1,k=0;
	while(i<=md && j<=r ){
		if(a[i] <= a[j])
			temp[k++] = a[i++];
		else
			temp[k++] = a[j++];	
	}

	while(i <= md){
		temp[k++] = a[i++];	
	}
	while(j <= r){
		temp[k++] = a[j++];	
	}
	for(int i=0;i<k;i++)
		a[l+i] = temp[i];
}

void merg