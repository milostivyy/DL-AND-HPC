#include<iostream>
#include<cuda_runtime.h>

__global__ void addVectors(int* A,int* B,int* C,int n){
int i=blockIdx.x* blockDim.x+threadId.x;
if(i<n){
C[i]=A[i]+B[i];
}
}

