#include <bits/stdc++.h>
#include <omp.h>
#include <chrono>
using namespace std;
using namespace std::chrono;


//Program to find maximum
void max_seq(vector<int> a, int n) {
	int mx = INT_MIN;
	for(int i = 0; i < n; i++) if(a[i] > mx) mx = a[i];	
	cout << "Maximum value:" << mx << endl; 
}

//Program to find minimum
void min_seq(vector<int> a, int n) {
	int mn = INT_MAX;
	
	for(int i = 0; i < n; i++) if(a[i] < mn) mn = a[i];
	
	cout << "Minimum value:" << mn << endl; 
}



//Program to find sum
void sum_seq(vector<int> a, int n) {
	int sum = 0;
	
	for(int i = 0; i < n; i++) sum += a[i];
	
	cout << "Sum: " << sum << endl; 
}


//Each operation calculates sum of all subsets of data
//The partial sums from each processor are added to obtain overall sum
//The overall sum is divided by total numbe of data elements to obtain average.
void avg_seq(vector<int> a, int n) {
	double sum = 0, cnt = n;
	
	for(int i = 0; i < n; i++) sum += a[i];
	double avg = sum / cnt;
	cout << "Average: " << avg << endl; 
}


//Program to find maximum using reduction
//Each processor compares its subsets of data to find maximum value
//The maximum value from each processor aer then compared to find overall maximum value
void max_red(vector<int> a, int n) {
	int mx = INT_MIN;
	#pragma omp parallel for reduction(max: mx)
	for(int i = 0; i < n; i++) if(a[i] > mx) mx = a[i];
	
	cout << "Maximum value: " << mx << endl; 
}
//Program to find minimum using reduction
//Each processor compares its subsets of data to find minimum value
//The minimum value from each processor aer then compared to find overall minimum value
void min_red(vector<int> a, int n) {
	int mn = INT_MAX;
	
	#pragma omp parallel for reduction(min: mn)
	for(int i = 0; i < n; i++) if(a[i] < mn) mn = a[i];
	
	cout << "Minimum value: " << mn << endl; 
}


//Each operation calculates sum of all subsets of data
//The partial sums from each processor are added to obtain overall sum
void sum_red(vector<int> a, int n) {
	int sum = 0;
	
	#pragma omp parallel for reduction(+: sum)
	for(int i = 0; i < n; i++) sum += a[i];
	
	cout << "Sum: " << sum << endl; 
}


//Each operation calculates sum of all subsets of data
//The partial sums from each processor are added to obtain overall sum
void avg_red(vector<int> a, int n) {
	double sum = 0, cnt = n;
	
	#pragma omp parallel for reduction(+: sum)
	for(int i = 0; i < n; i++) sum += a[i];
	double avg = sum / cnt;
	cout << "Average: " << avg << endl; 
}

int main() {
    const int SIZE = 100;
int N=100;
//Used chrono library to fidn time duration for each of the function used before
    vector<int> arr(SIZE);
    unsigned seed = chrono::system_clock::now().time_since_epoch().count();
    default_random_engine generator(seed);
    uniform_int_distribution<int> distribution(1, 1000);
    for (int i = 0; i < SIZE; i++) {
	arr[i] = distribution(generator);
    }
	auto start = high_resolution_clock::now();
	max_seq(arr, N);
	auto stop = high_resolution_clock::now();
   	auto duration = duration_cast<microseconds>(stop - start);
	cout<<"sequential time-"<<duration.count()<<endl;
	start = high_resolution_clock::now();
	max_red(arr, N);
	stop = high_resolution_clock::now();
   	duration = duration_cast<microseconds>(stop - start);
	cout<<"parallel time-"<<duration.count()<<endl;
	
	start = high_resolution_clock::now();
	min_seq(arr, N);
	stop = high_resolution_clock::now();
   	duration = duration_cast<microseconds>(stop - start);
	cout<<"sequential time-"<<duration.count()<<endl;
	start = high_resolution_clock::now();
	min_red(arr, N);
	stop = high_resolution_clock::now();
   	duration = duration_cast<microseconds>(stop - start);
	cout<<"parallel time-"<<duration.count()<<endl;
	
	start = high_resolution_clock::now();
	sum_red(arr, N);
	stop = high_resolution_clock::now();
   	duration = duration_cast<microseconds>(stop - start);
	cout<<"parallel time-"<<duration.count()<<endl;
	start = high_resolution_clock::now();
	sum_seq(arr, N);
	stop = high_resolution_clock::now();
   	duration = duration_cast<microseconds>(stop - start);
	cout<<"sequential time-"<<duration.count()<<endl;
	
	
	start = high_resolution_clock::now();
	avg_seq(arr, N);
	stop = high_resolution_clock::now();
   	duration = duration_cast<microseconds>(stop - start);
	cout<<"sequential time-"<<duration.count()<<endl;
	start = high_resolution_clock::now();
	avg_red(arr, N);
	stop = high_resolution_clock::now();
   	duration = duration_cast<microseconds>(stop - start);
	cout<<"parallel time-"<<duration.count()<<endl;
return 0;
}
	
