#include <bits/stdc++.h>
#include <omp.h>
#include <chrono>
using namespace std;
using namespace std::chrono;

void bubble_sort(vector<int>& arr){
    bool swapped=1;
    // Start a parallel region with all threads sharing the arr, n, and swapped variables
    #pragma omp parallel default(none) shared(arr, swapped)
    while(swapped){
        swapped = false;
        // Divide the for loop iterations among the threads
        #pragma omp for
        for (int i = 0; i < 100; ++i) {
            if (arr[i] > arr[i + 1]) {
                std::swap(arr[i], arr[i + 1]);
                swapped = true;
            }
        }
    }
}

void sbubble_sort(vector<int>& arr){
    bool swapped=1;
    while(swapped){
        swapped = false;
        for (int i = 0; i < 100; ++i) {
            if (arr[i] > arr[i + 1]) {
                std::swap(arr[i], arr[i + 1]);
                swapped = true;
            }
        }
    }
}

int main(){
    const int SIZE = 100;
    vector<int> arr(SIZE);

    // Generate a random seed based on the current time
    unsigned seed = chrono::system_clock::now().time_since_epoch().count();
    default_random_engine generator(seed);
    // Generate random numbers between 1 and 1000 and store them in the array
    uniform_int_distribution<int> distribution(1, 1000);
    for (int i = 0; i < SIZE; i++) {
        arr[i] = distribution(generator);
    }

    // Time the sequential bubble sort
    auto start = high_resolution_clock::now();
    bubble_sort(arr);
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<nanoseconds>(stop - start);
    cout<<" time taken by sequential bubble sorting: "<<duration.count()<<endl;

    // Time the parallel bubble sort
    start = high_resolution_clock::now();
    sbubble_sort(arr);
    stop = high_resolution_clock::now();
    duration = duration_cast<nanoseconds>(stop - start);
    cout<<" time taken by parallel bubble sorting: "<<duration.count()<<endl;

    // Print the sorted array
    for(int i=0;i<100;i++)
        cout<<arr[i]<<" ";    
    cout<<endl;
    char* username = std::getenv("USER"); // Get the value of the USER environment variable
  std::cout << "Username folder: /root/ 3427 Mahima Chauhan" << username << std::endl; // Output the username folder
    return 0;
}
